import torch


class CustomOptimizer(object):
    def __init__(self, prarams, base_lr, total_epoch, warm_up_epoch, restart_times):
        pass

    def optimizer_step():
        pass

    def scheduler_step():
        pass
